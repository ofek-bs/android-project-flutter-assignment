package com.technion.android.hellome.hello_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
